<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** One screen for every global business detail. Used in header, footer, forms and schema. */
function aps_settings_fields() {
	return [
		'company_name' => [ 'Company name', 'Agri Phero Solutionz Pvt. Ltd.' ],
		'tagline'      => [ 'Tagline', 'Protecting Crop • Creating Life' ],
		'phone'        => [ 'Phone', '' ],
		'whatsapp'     => [ 'WhatsApp number (digits only, with country code)', '' ],
		'email'        => [ 'Public email', '' ],
		'address'      => [ 'Address', 'Cherlapally, Hyderabad, Telangana, India' ],
		'gstin'        => [ 'GSTIN', '' ],
		'maps_embed'   => [ 'Google Maps embed URL', '' ],
		'shop_url'     => [ 'SHOP site URL', '' ],
		'youtube'      => [ 'YouTube channel URL', '' ],
		'linkedin'     => [ 'LinkedIn URL', '' ],
		'facebook'     => [ 'Facebook URL', '' ],
		'instagram'    => [ 'Instagram URL', '' ],
		'ga4_id'       => [ 'Google Analytics 4 ID (G-XXXXXXX)', '' ],
		'calc_data'    => [ 'Calculator data (one crop per line: Crop | Pest | Trap | Traps per acre | Lure life days)', "Mango | Fruit Fly | APS Easy/Maxfill Fruit Fly Trap | 8 | 65\nCotton | Pink Bollworm | APS PBW Trapper Kit | 10 | 55\nMaize | Fall Armyworm | APS FAW Funnel Trap | 6 | 45\nGuava | Fruit Fly | APS Easy Fruit Fly Trap | 8 | 65\nTomato | Tuta Absoluta / Fruit Borer | APS Delta / Sticky Trap | 12 | 50\nChilli | Thrips & Whitefly | APS Bio-Chromatic Yellow & Blue | 20 | 90" ],
		'metric_1'     => [ 'Counter 1 (e.g. 90+% fewer chemical sprays)', '90' ],
		'metric_2'     => [ 'Counter 2', '22' ],
		'metric_3'     => [ 'Counter 3', '60' ],
		'metric_4'     => [ 'Counter 4', '0' ],
	];
}

function aps_setting( $key, $fallback = '' ) {
	$opts = get_option( 'aps_settings', [] );
	if ( isset( $opts[ $key ] ) && $opts[ $key ] !== '' ) return $opts[ $key ];
	return aps_settings_fields()[ $key ][1] ?? $fallback;
}

add_action( 'admin_menu', function () {
	add_menu_page( 'APS Settings', 'APS Settings', 'manage_options', 'aps-settings', 'aps_settings_page', 'dashicons-admin-generic', 3 );
} );
add_action( 'admin_init', function () {
	register_setting( 'aps_settings_group', 'aps_settings', [ 'sanitize_callback' => function ( $in ) {
		$out = [];
		foreach ( aps_settings_fields() as $k => $def ) $out[ $k ] = isset( $in[ $k ] ) ? ( $k === 'calc_data' ? sanitize_textarea_field( $in[ $k ] ) : sanitize_text_field( $in[ $k ] ) ) : '';
		return $out;
	} ] );
} );
function aps_settings_page() {
	$opts = get_option( 'aps_settings', [] );
	echo '<div class="wrap"><h1>APS Settings</h1><p>Company details used across the whole website. Change them here once.</p><form method="post" action="options.php">';
	settings_fields( 'aps_settings_group' );
	echo '<table class="form-table">';
	foreach ( aps_settings_fields() as $k => [ $label, $default ] ) {
		if ( $k === 'calc_data' ) {
			printf( '<tr><th><label for="%1$s">%2$s</label></th><td><textarea class="large-text code" rows="8" id="%1$s" name="aps_settings[%1$s]">%3$s</textarea></td></tr>', esc_attr( $k ), esc_html( $label ), esc_textarea( $opts[ $k ] ?? $default ) );
			continue;
		}
		printf( '<tr><th><label for="%1$s">%2$s</label></th><td><input class="regular-text" id="%1$s" name="aps_settings[%1$s]" value="%3$s" placeholder="%4$s"></td></tr>',
			esc_attr( $k ), esc_html( $label ), esc_attr( $opts[ $k ] ?? '' ), esc_attr( $default ) );
	}
	echo '</table>'; submit_button(); echo '</form></div>';
}

/** Shortcode usable in any block: [aps field="phone"] */
add_shortcode( 'aps', fn( $a ) => esc_html( aps_setting( $a['field'] ?? '' ) ) );

/** GA4 snippet, controlled from APS Settings. */
add_action( 'wp_head', function () {
	$id = aps_setting( 'ga4_id' );
	if ( ! $id || ! preg_match( '/^G-[A-Z0-9]+$/', $id ) ) return;
	echo "<script async src='https://www.googletagmanager.com/gtag/js?id=$id'></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','$id');</script>";
} );
