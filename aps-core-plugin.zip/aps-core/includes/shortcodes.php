<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** [aps_meta key="target_pest"] — show an editable product/pest field anywhere in a template. */
add_shortcode( 'aps_meta', function ( $a ) {
	$v = get_post_meta( get_the_ID(), 'aps_' . sanitize_key( $a['key'] ?? '' ), true );
	return $v ? esc_html( $v ) : '';
} );

/** [aps_specs] — specs table from the "Label | Value" lines field. */
add_shortcode( 'aps_specs', function () {
	$raw = get_post_meta( get_the_ID(), 'aps_specs', true );
	if ( ! $raw ) return '';
	$rows = '';
	foreach ( preg_split( '/\r?\n/', $raw ) as $line ) {
		if ( strpos( $line, '|' ) === false ) continue;
		[ $k, $v ] = array_map( 'trim', explode( '|', $line, 2 ) );
		$rows .= '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
	}
	return $rows ? '<table class="aps-specs"><tbody>' . $rows . '</tbody></table>' : '';
} );

/** [aps_facts] — quick-fact cards (target pest, crops, dosage, lure life) from product fields. */
add_shortcode( 'aps_facts', function () {
	$id = get_the_ID(); $out = '';
	foreach ( [ 'target_pest' => 'Target pest', 'crops' => 'Suitable crops', 'dosage' => 'Dosage', 'lure_life' => 'Lure field life' ] as $k => $label ) {
		$v = get_post_meta( $id, 'aps_' . $k, true );
		if ( $v ) $out .= '<div class="aps-fact"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( $v ) . '</strong></div>';
	}
	return $out ? '<div class="aps-facts">' . $out . '</div>' : '';
} );

/** [aps_buttons] — datasheet / buy / enquiry buttons from the product fields. */
add_shortcode( 'aps_buttons', function () {
	$id = get_the_ID(); $out = '';
	$label = get_post_meta( $id, 'aps_enquiry_label', true ) ?: 'Enquire about this product';
	$wa = preg_replace( '/\D/', '', aps_setting( 'whatsapp' ) );
	if ( $wa ) $out .= '<a class="aps-btn-solid" href="https://wa.me/' . esc_attr( $wa ) . '?text=' . rawurlencode( 'Hello, I would like to enquire about ' . get_the_title( $id ) ) . '">' . esc_html( $label ) . '</a> ';
	if ( $u = get_post_meta( $id, 'aps_datasheet_url', true ) ) $out .= '<a class="aps-btn-outline" href="' . esc_url( $u ) . '">Download datasheet</a> ';
	if ( $u = get_post_meta( $id, 'aps_shop_url', true ) ) $out .= '<a class="aps-btn-outline" href="' . esc_url( $u ) . '">Buy on shop</a>';
	return '<div class="aps-buttons">' . $out . '</div>';
} );

/**
 * [aps_trap_calculator] — crop → traps needed. Rates are edited in APS Settings (one crop per line:
 * Crop | Pest | Trap | Traps per acre | Lure life days).
 */
add_shortcode( 'aps_trap_calculator', function () {
	$rows = [];
	foreach ( preg_split( '/\r?\n/', (string) aps_setting( 'calc_data' ) ) as $line ) {
		$p = array_map( 'trim', explode( '|', $line ) );
		if ( count( $p ) >= 5 ) $rows[ $p[0] ] = [ 'pest' => $p[1], 'trap' => $p[2], 'perAcre' => (float) $p[3], 'life' => (int) $p[4] ];
	}
	if ( ! $rows ) return '';
	wp_enqueue_script( 'aps-calculator', plugins_url( 'assets/calculator.js', dirname( __FILE__ ) ), [], '0.1.0', true );
	wp_localize_script( 'aps-calculator', 'APS_CALC', $rows );
	$opts = ''; foreach ( array_keys( $rows ) as $c ) $opts .= '<option>' . esc_html( $c ) . '</option>';
	$wa = preg_replace( '/\D/', '', aps_setting( 'whatsapp' ) );
	return '<div class="aps-calc aps-card" data-wa="' . esc_attr( $wa ) . '"><h3>Trap requirement calculator</h3>
	<label>Crop <select class="aps-calc-crop">' . $opts . '</select></label>
	<label>Area (acres) <input class="aps-calc-acres" type="number" min="1" value="5"></label>
	<div class="aps-calc-result" aria-live="polite"></div></div>';
} );

/** [aps_map] — Google Maps embed from APS Settings (paste the iframe src URL). */
add_shortcode( 'aps_map', function () {
	$u = aps_setting( 'maps_embed' );
	if ( ! $u ) return current_user_can( 'manage_options' ) ? '<p><em>Admin note: add the Google Maps embed URL in APS Settings to show the map.</em></p>' : '';
	return '<iframe class="aps-map" title="APS location" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="' . esc_url( $u ) . '" width="100%" height="320" style="border:0;border-radius:16px"></iframe>';
} );
