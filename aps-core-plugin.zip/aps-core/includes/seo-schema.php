<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Organization + Product JSON-LD generated from the editable fields (no code edits needed by the client). */
add_action( 'wp_head', function () {
	$social = array_values( array_filter( [ aps_setting( 'youtube' ), aps_setting( 'linkedin' ), aps_setting( 'facebook' ), aps_setting( 'instagram' ) ] ) );
	if ( is_front_page() ) {
		$data = [
			'@context' => 'https://schema.org', '@type' => 'Organization',
			'name' => aps_setting( 'company_name' ), 'url' => home_url( '/' ),
			'logo' => get_site_icon_url() ?: '', 'slogan' => aps_setting( 'tagline' ),
			'address' => [ '@type' => 'PostalAddress', 'streetAddress' => aps_setting( 'address' ), 'addressCountry' => 'IN' ],
			'contactPoint' => array_filter( [ '@type' => 'ContactPoint', 'telephone' => aps_setting( 'phone' ), 'email' => aps_setting( 'email' ), 'contactType' => 'sales' ] ),
			'sameAs' => $social,
		];
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
	}
	if ( is_singular( 'aps_product' ) ) {
		$id = get_the_ID();
		$data = [
			'@context' => 'https://schema.org', '@type' => 'Product',
			'name' => get_the_title( $id ), 'description' => wp_strip_all_tags( get_the_excerpt( $id ) ),
			'image' => get_the_post_thumbnail_url( $id, 'large' ) ?: '',
			'brand' => [ '@type' => 'Brand', 'name' => aps_setting( 'company_name' ) ],
			'manufacturer' => [ '@type' => 'Organization', 'name' => aps_setting( 'company_name' ) ],
		];
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
	}
}, 5 );
