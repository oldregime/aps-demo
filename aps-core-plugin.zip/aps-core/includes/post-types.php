<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Content types the client can add/edit/duplicate/unpublish from the dashboard. */
function aps_register_post_types() {
	$types = [
		'aps_product'       => [ 'Products', 'Product', 'products', 'dashicons-products' ],
		'aps_pest'          => [ 'Pests', 'Pest', 'pests', 'dashicons-bug' ],
		'aps_crop'          => [ 'Crops', 'Crop', 'crops', 'dashicons-carrot' ],
		'aps_document'      => [ 'Documents (TDS/MSDS)', 'Document', 'documents', 'dashicons-media-document' ],
		'aps_news'          => [ 'News & Announcements', 'News item', 'news', 'dashicons-megaphone' ],
		'aps_event'         => [ 'Events', 'Event', 'events', 'dashicons-calendar-alt' ],
		'aps_certification' => [ 'Certifications', 'Certification', 'certifications', 'dashicons-awards' ],
		'aps_knowledge'     => [ 'APS Agri Jnanam', 'Article', 'agri-jnanam', 'dashicons-welcome-learn-more' ],
	];
	foreach ( $types as $key => [ $plural, $single, $slug, $icon ] ) {
		register_post_type( $key, [
			'labels'       => [
				'name' => $plural, 'singular_name' => $single,
				'add_new_item' => "Add new $single", 'edit_item' => "Edit $single",
			],
			'public'       => true,
			'show_in_rest' => true,           // block editor + REST for tooling
			'has_archive'  => $slug,
			'rewrite'      => [ 'slug' => $slug ],
			'menu_icon'    => $icon,
			'supports'     => [ 'title', 'editor', 'excerpt', 'thumbnail', 'revisions', 'page-attributes' ],
		] );
	}

	register_taxonomy( 'aps_product_cat', 'aps_product', [
		'label' => 'Product categories', 'public' => true, 'hierarchical' => true,
		'show_in_rest' => true, 'rewrite' => [ 'slug' => 'product-category' ],
	] );
	register_taxonomy( 'aps_doc_type', 'aps_document', [
		'label' => 'Document types', 'public' => true, 'hierarchical' => true,
		'show_in_rest' => true, 'rewrite' => [ 'slug' => 'document-type' ],
	] );
}
add_action( 'init', 'aps_register_post_types' );

/** Make every content type translatable in Polylang (English / Hindi / Telugu). */
add_filter( 'pll_get_post_types', function ( $types, $is_settings ) {
	foreach ( [ 'aps_product','aps_pest','aps_crop','aps_document','aps_news','aps_event','aps_certification','aps_knowledge' ] as $t ) $types[ $t ] = $t;
	return $types;
}, 10, 2 );
add_filter( 'pll_get_taxonomies', function ( $taxes ) {
	$taxes['aps_product_cat'] = 'aps_product_cat';
	$taxes['aps_doc_type']    = 'aps_doc_type';
	return $taxes;
}, 10, 1 );
