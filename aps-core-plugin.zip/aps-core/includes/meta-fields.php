<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Editable fields per content type. Add a line here and it appears in the editor
 * as a simple form — no code needed in templates to make it editable.
 * type: text | textarea | url | number | media (attachment URL) | select
 */
function aps_field_map() {
	return [
		'aps_product' => [
			'target_pest'   => [ 'Target pest(s)', 'text' ],
			'crops'         => [ 'Suitable crops', 'text' ],
			'dosage'        => [ 'Dosage / traps per acre', 'text' ],
			'lure_life'     => [ 'Lure field life (days)', 'text' ],
			'specs'         => [ 'Technical specifications (one per line: Label | Value)', 'textarea' ],
			'video_url'     => [ 'YouTube video URL', 'url' ],
			'datasheet_url' => [ 'Datasheet / brochure PDF', 'media' ],
			'shop_url'      => [ 'Buy link (SHOP subdomain)', 'url' ],
			'enquiry_label' => [ 'Enquiry button text', 'text' ],
		],
		'aps_pest' => [
			'scientific_name' => [ 'Scientific name', 'text' ],
			'affected_crops'  => [ 'Affected crops', 'text' ],
			'damage'          => [ 'Damage symptoms', 'textarea' ],
			'monitoring'      => [ 'Monitoring & trap density', 'textarea' ],
			'faq'             => [ 'FAQ (Question | Answer, one per line)', 'textarea' ],
		],
		'aps_crop' => [
			'key_pests' => [ 'Key pests', 'text' ],
			'calendar'  => [ 'Crop-stage pest calendar (Stage | Pest | Action, one per line)', 'textarea' ],
		],
		'aps_document' => [
			'file_url'   => [ 'File (PDF)', 'media' ],
			'product_id' => [ 'Related product ID (optional)', 'number' ],
			'version'    => [ 'Version / date', 'text' ],
		],
		'aps_event' => [
			'event_date' => [ 'Date', 'text' ],
			'location'   => [ 'Location', 'text' ],
			'link'       => [ 'More info link', 'url' ],
		],
		'aps_certification' => [
			'issuer'      => [ 'Issuing body', 'text' ],
			'valid_until' => [ 'Valid until', 'text' ],
			'file_url'    => [ 'Certificate file', 'media' ],
		],
	];
}

add_action( 'init', function () {
	foreach ( aps_field_map() as $post_type => $fields ) {
		foreach ( $fields as $key => $def ) {
			register_post_meta( $post_type, "aps_$key", [
				'show_in_rest' => true, 'single' => true,
				'type' => $def[1] === 'number' ? 'integer' : 'string',
				'sanitize_callback' => $def[1] === 'textarea' ? 'sanitize_textarea_field' : ( $def[1] === 'url' || $def[1] === 'media' ? 'esc_url_raw' : 'sanitize_text_field' ),
				'auth_callback' => fn() => current_user_can( 'edit_posts' ),
			] );
		}
	}
} );

add_action( 'add_meta_boxes', function () {
	foreach ( aps_field_map() as $post_type => $fields ) {
		add_meta_box( 'aps_fields', 'Details', function ( $post ) use ( $fields ) {
			wp_nonce_field( 'aps_save_fields', 'aps_nonce' );
			echo '<table class="form-table" role="presentation">';
			foreach ( $fields as $key => [ $label, $type ] ) {
				$val = get_post_meta( $post->ID, "aps_$key", true );
				echo '<tr><th><label for="aps_' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
				if ( $type === 'textarea' ) {
					printf( '<textarea class="large-text" rows="5" id="aps_%1$s" name="aps_%1$s">%2$s</textarea>', esc_attr( $key ), esc_textarea( $val ) );
				} else {
					printf( '<input class="large-text" type="%1$s" id="aps_%2$s" name="aps_%2$s" value="%3$s">', $type === 'number' ? 'number' : ( $type === 'url' || $type === 'media' ? 'url' : 'text' ), esc_attr( $key ), esc_attr( $val ) );
					if ( $type === 'media' ) echo '<p class="description">Paste a file URL, or upload in Media Library and copy its URL.</p>';
				}
				echo '</td></tr>';
			}
			echo '</table>';
		}, $post_type, 'normal', 'high' );
	}
} );

add_action( 'save_post', function ( $post_id ) {
	if ( ! isset( $_POST['aps_nonce'] ) || ! wp_verify_nonce( $_POST['aps_nonce'], 'aps_save_fields' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;
	$map = aps_field_map()[ get_post_type( $post_id ) ] ?? [];
	foreach ( $map as $key => [ $label, $type ] ) {
		if ( ! isset( $_POST[ "aps_$key" ] ) ) continue;
		$raw = wp_unslash( $_POST[ "aps_$key" ] );
		$val = $type === 'textarea' ? sanitize_textarea_field( $raw ) : ( in_array( $type, [ 'url', 'media' ], true ) ? esc_url_raw( $raw ) : sanitize_text_field( $raw ) );
		update_post_meta( $post_id, "aps_$key", $val );
	}
} );
