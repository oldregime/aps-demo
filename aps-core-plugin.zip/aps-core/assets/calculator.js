document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.aps-calc').forEach(function (box) {
    var crop = box.querySelector('.aps-calc-crop'), acres = box.querySelector('.aps-calc-acres'), out = box.querySelector('.aps-calc-result');
    function render() {
      var d = APS_CALC[crop.value], a = Math.max(1, parseFloat(acres.value) || 1);
      if (!d) { out.textContent = ''; return; }
      var traps = Math.ceil(d.perAcre * a);
      var msg = 'Hello, I need ' + traps + ' x ' + d.trap + ' for ' + a + ' acres of ' + crop.value + '.';
      out.innerHTML = '<p><strong>' + traps + ' traps</strong> of <em>' + d.trap + '</em> for ' + a + ' acre(s) of ' + crop.value +
        '.</p><p>Target pest: ' + d.pest + ' · Lure lasts about ' + d.life + ' days.</p>' +
        (box.dataset.wa ? '<a class="wp-element-button" href="https://wa.me/' + box.dataset.wa + '?text=' + encodeURIComponent(msg) + '">Get a quote on WhatsApp</a>' : '');
    }
    crop.addEventListener('change', render); acres.addEventListener('input', render); render();
  });
});
