<?php
/**
 * Plugin Name: APS Core
 * Description: Content types, global settings and helpers for the Agri Phero Solutionz website. Keep this active — it holds the data model so content survives theme changes.
 * Version: 0.1.0
 * Text Domain: aps-core
 */
if ( ! defined( 'ABSPATH' ) ) exit;
define( 'APS_CORE_DIR', plugin_dir_path( __FILE__ ) );
require_once APS_CORE_DIR . 'includes/post-types.php';
require_once APS_CORE_DIR . 'includes/meta-fields.php';
require_once APS_CORE_DIR . 'includes/settings.php';
require_once APS_CORE_DIR . 'includes/seo-schema.php';
require_once APS_CORE_DIR . 'includes/shortcodes.php';

register_activation_hook( __FILE__, function () {
	aps_register_post_types();
	flush_rewrite_rules();
} );

/** Local development only: route all WordPress email to the Mailpit container. */
if ( function_exists( 'wp_get_environment_type' ) ) {
	add_action( 'phpmailer_init', function ( $m ) {
		if ( wp_get_environment_type() !== 'local' ) return;
		$m->isSMTP(); $m->Host = 'mailpit'; $m->Port = 1025; $m->SMTPAuth = false; $m->SMTPAutoTLS = false;
	}, 99999 );
}
