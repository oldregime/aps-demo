<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'wp_enqueue_scripts', function () {
	// Brand fonts (self-host in production for speed/privacy — see README).
	wp_enqueue_style( 'aps-fonts', 'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@500;700&family=Playfair+Display:wght@400;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Noto+Sans+Devanagari:wght@400;600&family=Noto+Sans+Telugu:wght@400;600&display=swap', [], null );
	wp_enqueue_style( 'aps-theme', get_stylesheet_uri(), [], wp_get_theme()->get( 'Version' ) );
	wp_enqueue_style( 'aps-main', get_theme_file_uri( 'assets/css/main.css' ), [ 'aps-theme' ], wp_get_theme()->get( 'Version' ) );
} );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	register_nav_menus( [ 'primary' => 'Primary menu', 'footer' => 'Footer menu' ] );
} );

add_action( 'init', function () {
	register_block_pattern_category( 'aps', [ 'label' => 'APS sections' ] );
} );
